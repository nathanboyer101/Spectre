# Spectre AdBlocker — Installation Firefox Android

## Prérequis
- Firefox **Nightly** ou **Firefox Beta** sur Android
  (Firefox stable ne permet plus les extensions non-AMO depuis 2023)
- Un compte Mozilla (gratuit) pour signer l'extension

---

## Étape 1 — Signer l'extension (obligatoire)

Mozilla exige que toute extension soit signée pour tourner sur Firefox Android.

### Option A — Mozilla Add-on Developer Hub (recommandé)

1. Va sur https://addons.mozilla.org/developers/
2. Crée un compte si besoin
3. Clique **"Submit a New Add-on"** → **"On this site"**
4. Upload le fichier `spectre-adblocker-firefox.zip`
5. Remplis les infos (nom, description) → soumets pour révision
6. Une fois approuvé (quelques jours), télécharge le `.xpi` signé

### Option B — Self-signing avec `web-ext` (immédiat, pour test perso)

```bash
# Installer web-ext
npm install -g web-ext

# Générer des clés API sur https://addons.mozilla.org/fr/developers/addon/api/key/
# Puis signer localement :
web-ext sign \
  --source-dir ./spectre-adblocker-firefox \
  --api-key=user:XXXXX \
  --api-secret=XXXXXXXXXXXXXXXX
```
→ Génère un `.xpi` signé dans `./web-ext-artifacts/`

---

## Étape 2 — Installer sur Firefox Android

### Avec Firefox Nightly (le plus simple)

1. Ouvre Firefox Nightly sur ton téléphone
2. Va dans **⋮ Menu → Paramètres → À propos de Firefox Nightly**
3. Tape **5 fois** sur le logo Firefox → "Mode débogage activé"
4. Retourne dans Paramètres → **"Installer une extension depuis un fichier"**
5. Sélectionne ton fichier `.xpi` signé
6. Confirme l'installation → l'extension apparaît dans les extensions

### Avec Firefox Beta

Même procédure que Nightly.

### Avec Firefox stable (via AMO uniquement)

Si ton extension est approuvée sur AMO :
1. Va sur la page de l'extension sur addons.mozilla.org depuis ton téléphone
2. Clique "Ajouter à Firefox"

---

## Étape 3 — Activer et utiliser

1. Dans Firefox Android, ouvre n'importe quel site avec des pubs
2. Tape sur **⋮ Menu → Extensions** pour voir Spectre AdBlocker
3. Tape sur l'icône de l'extension pour ouvrir le popup
4. Ajoute tes images (fichier ou URL) et règle les fréquences

---

## Notes importantes

- **`webRequest` blocking** : contrairement à Chrome MV3, Firefox Android supporte toujours le blocage réseau via `webRequest` — les pubs sont bloquées au niveau réseau ET remplacées visuellement
- Les images uploadées sont stockées localement dans `browser.storage.local` (pas de cloud)
- Le popup fonctionne identiquement à la version Chrome

---

## Différences techniques vs version Chrome

| Fonctionnalité | Chrome (MV3) | Firefox Android (MV2) |
|---|---|---|
| Blocage réseau | `declarativeNetRequest` | `webRequest` + `blocking` |
| API | `chrome.*` | `browser.*` |
| Background | Service Worker | Script persistant |
| Manifest | v3 | v2 |
| Popup | `action` | `browser_action` |
