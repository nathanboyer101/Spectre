/* Spectre AdBlocker — background.js (Firefox) */

const DEFAULT_IMAGES = [
  "images/default1.jpg",
  "images/default2.jpg",
  "images/default3.jpg",
  "images/default4.jpg",
  "images/default5.jpg",
  "images/default6.jpg",
  "images/default7.jpg",
  "images/default8.jpg"
];

// ── Ad domains to block via webRequest ───────────────────────────────────────
const AD_URL_PATTERNS = [
  "*://*.doubleclick.net/*",
  "*://*.googlesyndication.com/*",
  "*://*.googleadservices.com/*",
  "*://*.googletagservices.com/*",
  "*://*.amazon-adsystem.com/*",
  "*://*.criteo.com/*",
  "*://*.criteo.net/*",
  "*://*.taboola.com/*",
  "*://*.outbrain.com/*",
  "*://*.smartadserver.com/*",
  "*://*.sparteo.com/*",
  "*://*.appnexus.com/*",
  "*://*.xandr.com/*",
  "*://*.adnxs.com/*",
  "*://*.pubmatic.com/*",
  "*://*.rubiconproject.com/*",
  "*://*.openx.net/*",
  "*://*.openx.com/*",
  "*://*.casalemedia.com/*",
  "*://*.indexexchange.com/*",
  "*://*.adform.net/*",
  "*://*.adform.com/*",
  "*://*.adroll.com/*",
  "*://*.advertising.com/*",
  "*://ads.yahoo.com/*",
  "*://ads.twitter.com/*",
  "*://static.ads-twitter.com/*",
  "*://ads.tiktok.com/*",
  "*://analytics.tiktok.com/*",
  "*://*.bidswitch.net/*",
  "*://*.smaato.net/*",
  "*://*.lijit.com/*",
  "*://*.sonobi.com/*",
  "*://*.yieldmo.com/*",
  "*://*.media.net/*",
  "*://*.revcontent.com/*",
  "*://*.mgid.com/*",
  "*://*.sharethrough.com/*",
  "*://*.triplelift.com/*",
  "*://*.districtm.io/*",
  "*://*.teads.tv/*",
  "*://*.adsafeprotected.com/*",
  "*://*.doubleverify.com/*",
  "*://*.moatads.com/*",
  "*://*.moatpixel.com/*",
  "*://*.scorecardresearch.com/*",
  "*://*.everesttech.net/*",
  "*://*.adtech.de/*",
  "*://*.adtech.com/*",
  "*://*.contextweb.com/*",
  "*://*.pulsepoint.com/*",
  "*://*.33across.com/*",
  "*://*.emxdgt.com/*",
  "*://*.conversantmedia.com/*",
  "*://*.ligatus.com/*",
  "*://*.sublime.systems/*",
  "*://*.digiteka.net/*",
  "*://*.weborama.fr/*",
  "*://*.weborama.com/*",
  "*://*.adikteev.com/*",
  "*://*.tradedoubler.com/*",
  "*://*.zanox.com/*"
];

// ── First install ────────────────────────────────────────────────────────────
browser.runtime.onInstalled.addListener(() => {
  browser.storage.local.get(["allImages", "activeImages"]).then(data => {
    if (!data.allImages || data.allImages.length === 0) {
      browser.storage.local.set({
        allImages:    DEFAULT_IMAGES,
        activeImages: DEFAULT_IMAGES,
        imageWeights: {},
        freqMode:     "fair"
      });
    }
  });
});

// ── Block ad requests via webRequest ─────────────────────────────────────────
browser.webRequest.onBeforeRequest.addListener(
  () => ({ cancel: true }),
  { urls: AD_URL_PATTERNS, types: ["script", "sub_frame", "image", "xmlhttprequest"] },
  ["blocking"]
);
